#define EGLAPI
#define EGLAPIENTRY

#include <EGL/egl.h>
