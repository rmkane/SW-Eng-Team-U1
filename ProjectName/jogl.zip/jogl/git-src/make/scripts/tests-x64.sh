#! /bin/bash

spath=`dirname $0`

. $spath/tests.sh  /opt-linux-x86_64/j2se6/bin/java ../build-x86_64 $*


