#! /bin/bash

rm -rf ../build/test/* \
       ../build/jogl/jogl.test.jar \
       ../build/jar/jogl.test.jar

