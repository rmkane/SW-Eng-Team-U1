#! /bin/bash

rm -rf ../build/jogl/classes/jogamp/graph ../build/jogl/classes/com/jogamp/graph ../build/test/build/classes/com/jogamp/opengl/test/junit/graph
